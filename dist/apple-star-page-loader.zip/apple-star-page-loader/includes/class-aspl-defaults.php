<?php
/**
 * Default options & preset registry.
 *
 * @package Apple_Star_Loader
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ASPL_Defaults {

	/**
	 * Registry of all 100 loader presets (slug => human name).
	 *
	 * The first 11 are the v3.1 originals; the remaining 89 were added in
	 * v3.3.0. Every preset is a pure SVG + SMIL fragment — no CSS
	 * @keyframes, no JS — so animations survive CSS/JS optimizer plugins.
	 *
	 * @return array<string,string>
	 */
	public static function get_presets() {
		return array(
'apple_star'      => __( 'Apple Star Pulse (ECG)', 'apple-star-loader' ),
		'pulse_classic'   => __( 'Classic Pulse', 'apple-star-loader' ),
		'freq_bars'       => __( 'Equalizer Bars', 'apple-star-loader' ),
		'sine_wave'       => __( 'Sine Wave Dots', 'apple-star-loader' ),
		'ecg_heartbeat'   => __( 'ECG Heartbeat', 'apple-star-loader' ),
		'siri_orbit'      => __( 'Siri Orbit', 'apple-star-loader' ),
		'radar_sweep'     => __( 'Concentric Radar', 'apple-star-loader' ),
		'breathing_core'  => __( 'Breathing Core', 'apple-star-loader' ),
		'quantum_spin'    => __( 'Quantum Spin', 'apple-star-loader' ),
		'wave_morph'      => __( 'Wave Morph', 'apple-star-loader' ),
		'dot_rhythm'      => __( 'Dot Rhythm', 'apple-star-loader' ),
// --- 89 new v3.3.0 presets ---
		'rings_01' => __( 'حلقه‌های متحدالمرکز ۱', 'apple-star-loader' ),
		'rings_02' => __( 'حلقه‌های متحدالمرکز ۲', 'apple-star-loader' ),
		'rings_03' => __( 'حلقه‌های متحدالمرکز ۳', 'apple-star-loader' ),
		'rings_04' => __( 'حلقه‌های متحدالمرکز ۴', 'apple-star-loader' ),
		'rings_05' => __( 'حلقه‌های متحدالمرکز ۵', 'apple-star-loader' ),
		'halo_01' => __( 'هاله نورانی ۱', 'apple-star-loader' ),
		'halo_02' => __( 'هاله نورانی ۲', 'apple-star-loader' ),
		'halo_03' => __( 'هاله نورانی ۳', 'apple-star-loader' ),
		'halo_04' => __( 'هاله نورانی ۴', 'apple-star-loader' ),
		'bounce_01' => __( 'توپ‌های جهنده ۱', 'apple-star-loader' ),
		'bounce_02' => __( 'توپ‌های جهنده ۲', 'apple-star-loader' ),
		'bounce_03' => __( 'توپ‌های جهنده ۳', 'apple-star-loader' ),
		'bounce_04' => __( 'توپ‌های جهنده ۴', 'apple-star-loader' ),
		'bounce_05' => __( 'توپ‌های جهنده ۵', 'apple-star-loader' ),
		'bounce_06' => __( 'توپ‌های جهنده ۶', 'apple-star-loader' ),
		'wave_01' => __( 'موج سینوسی ۱', 'apple-star-loader' ),
		'wave_02' => __( 'موج سینوسی ۲', 'apple-star-loader' ),
		'wave_03' => __( 'موج سینوسی ۳', 'apple-star-loader' ),
		'wave_04' => __( 'موج سینوسی ۴', 'apple-star-loader' ),
		'wave_05' => __( 'موج سینوسی ۵', 'apple-star-loader' ),
		'eq_01' => __( 'اکولایزر ۱', 'apple-star-loader' ),
		'eq_02' => __( 'اکولایزر ۲', 'apple-star-loader' ),
		'eq_03' => __( 'اکولایزر ۳', 'apple-star-loader' ),
		'eq_04' => __( 'اکولایزر ۴', 'apple-star-loader' ),
		'eq_05' => __( 'اکولایزر ۵', 'apple-star-loader' ),
		'arc_01' => __( 'کمان چرخان ۱', 'apple-star-loader' ),
		'arc_02' => __( 'کمان چرخان ۲', 'apple-star-loader' ),
		'arc_03' => __( 'کمان چرخان ۳', 'apple-star-loader' ),
		'arc_04' => __( 'کمان چرخان ۴', 'apple-star-loader' ),
		'arc_05' => __( 'کمان چرخان ۵', 'apple-star-loader' ),
		'atom_01' => __( 'اتم مداری ۱', 'apple-star-loader' ),
		'atom_02' => __( 'اتم مداری ۲', 'apple-star-loader' ),
		'atom_03' => __( 'اتم مداری ۳', 'apple-star-loader' ),
		'atom_04' => __( 'اتم مداری ۴', 'apple-star-loader' ),
		'radar_01' => __( 'رادار چرخان ۱', 'apple-star-loader' ),
		'radar_02' => __( 'رادار چرخان ۲', 'apple-star-loader' ),
		'radar_03' => __( 'رادار چرخان ۳', 'apple-star-loader' ),
		'radar_04' => __( 'رادار چرخان ۴', 'apple-star-loader' ),
		'star_01' => __( 'ستاره‌های چشمک‌زن ۱', 'apple-star-loader' ),
		'star_02' => __( 'ستاره‌های چشمک‌زن ۲', 'apple-star-loader' ),
		'star_03' => __( 'ستاره‌های چشمک‌زن ۳', 'apple-star-loader' ),
		'star_04' => __( 'ستاره‌های چشمک‌زن ۴', 'apple-star-loader' ),
		'star_05' => __( 'ستاره‌های چشمک‌زن ۵', 'apple-star-loader' ),
		'ecg_line_01' => __( 'ضربان قلب ECG ۱', 'apple-star-loader' ),
		'ecg_line_02' => __( 'ضربان قلب ECG ۲', 'apple-star-loader' ),
		'ecg_line_03' => __( 'ضربان قلب ECG ۳', 'apple-star-loader' ),
		'ecg_line_04' => __( 'ضربان قلب ECG ۴', 'apple-star-loader' ),
		'ecg_line_05' => __( 'ضربان قلب ECG ۵', 'apple-star-loader' ),
		'orbit_01' => __( 'سیاره‌های مداری ۱', 'apple-star-loader' ),
		'orbit_02' => __( 'سیاره‌های مداری ۲', 'apple-star-loader' ),
		'orbit_03' => __( 'سیاره‌های مداری ۳', 'apple-star-loader' ),
		'orbit_04' => __( 'سیاره‌های مداری ۴', 'apple-star-loader' ),
		'infinity_01' => __( 'بی‌نهایت ۱', 'apple-star-loader' ),
		'infinity_02' => __( 'بی‌نهایت ۲', 'apple-star-loader' ),
		'infinity_03' => __( 'بی‌نهایت ۳', 'apple-star-loader' ),
		'infinity_04' => __( 'بی‌نهایت ۴', 'apple-star-loader' ),
		'morph_01' => __( 'مورف شکل ۱', 'apple-star-loader' ),
		'morph_02' => __( 'مورف شکل ۲', 'apple-star-loader' ),
		'morph_03' => __( 'مورف شکل ۳', 'apple-star-loader' ),
		'morph_04' => __( 'مورف شکل ۴', 'apple-star-loader' ),
		'morph_05' => __( 'مورف شکل ۵', 'apple-star-loader' ),
		'grid_01' => __( 'ماتریس نقطه‌ای ۱', 'apple-star-loader' ),
		'grid_02' => __( 'ماتریس نقطه‌ای ۲', 'apple-star-loader' ),
		'grid_03' => __( 'ماتریس نقطه‌ای ۳', 'apple-star-loader' ),
		'grid_04' => __( 'ماتریس نقطه‌ای ۴', 'apple-star-loader' ),
		'battery_01' => __( 'شارژ باتری ۱', 'apple-star-loader' ),
		'battery_02' => __( 'شارژ باتری ۲', 'apple-star-loader' ),
		'battery_03' => __( 'شارژ باتری ۳', 'apple-star-loader' ),
		'battery_04' => __( 'شارژ باتری ۴', 'apple-star-loader' ),
		'clock_01' => __( 'ساعت گردان ۱', 'apple-star-loader' ),
		'clock_02' => __( 'ساعت گردان ۲', 'apple-star-loader' ),
		'clock_03' => __( 'ساعت گردان ۳', 'apple-star-loader' ),
		'clock_04' => __( 'ساعت گردان ۴', 'apple-star-loader' ),
		'aperture_01' => __( 'دیافراگم دوربین ۱', 'apple-star-loader' ),
		'aperture_02' => __( 'دیافراگم دوربین ۲', 'apple-star-loader' ),
		'aperture_03' => __( 'دیافراگم دوربین ۳', 'apple-star-loader' ),
		'aperture_04' => __( 'دیافراگم دوربین ۴', 'apple-star-loader' ),
		'pinwheel_01' => __( 'پروانه چرخان ۱', 'apple-star-loader' ),
		'pinwheel_02' => __( 'پروانه چرخان ۲', 'apple-star-loader' ),
		'pinwheel_03' => __( 'پروانه چرخان ۳', 'apple-star-loader' ),
		'pinwheel_04' => __( 'پروانه چرخان ۴', 'apple-star-loader' ),
		'drop_01' => __( 'قطره آب ۱', 'apple-star-loader' ),
		'drop_02' => __( 'قطره آب ۲', 'apple-star-loader' ),
		'drop_03' => __( 'قطره آب ۳', 'apple-star-loader' ),
		'drop_04' => __( 'قطره آب ۴', 'apple-star-loader' ),
		'tri_01' => __( 'مثلث مداری ۱', 'apple-star-loader' ),
		'tri_02' => __( 'مثلث مداری ۲', 'apple-star-loader' ),
		'tri_03' => __( 'مثلث مداری ۳', 'apple-star-loader' ),
		'tri_04' => __( 'مثلث مداری ۴', 'apple-star-loader' ),
		);
	}

	/**
	 * Default option values (used on activation and as fallbacks).
	 *
	 * v3.3.0 timing defaults are tuned for an INSTANT reveal: the loader
	 * fades as soon as the DOM is ready (not after every image/font has
	 * downloaded), with a short minimum display time so it never flickers.
	 *
	 * @return array
	 */
	public static function get_options() {
		return array(
			'enabled'            => 1,
			'target'             => 'front_page',
			'preset'             => 'apple_star',
			'show_on_mobile'     => 1,
			'hide_for_logged_in' => 0,
			'text'               => 'APPLE STAR',
			'use_site_title'     => 1,
			'logo'               => '',
			'bg_color'           => '#000000',
			'bg_opacity'         => 85,
			'text_color'         => '#ffffff',
			'accent_color'       => '#00c3ff',
			'blur_amount'        => 16,
			// v3.3: hide when the DOM is interactive (fast) or after the
			// full window "load" event (only for pages that must wait for
			// every asset).
			'hide_when'          => 'dom_ready',
			'wait_images'        => 0,
			'timeout'            => 15,
			'min_time'           => 350,
			'fade_duration'      => 350,
			'z_index'            => 99999999,
			'maintenance_mode'   => 0,
			'maintenance_hours'  => 0,
			'maintenance_minutes'=> 30,
			'maintenance_seconds'=> 0,
			'maintenance_msg'    => 'ما در حال بروز رسانی هستیم. بزودی با ارائه خدمات بهتر در خدمت شما هستیم.',
			'custom_css'         => '',
		);
	}

	public static function get_preset_code( $slug ) {
		$file = ASPL_PLUGIN_DIR . 'assets/presets/' . sanitize_file_name( (string) $slug ) . '.html';
		if ( file_exists( $file ) ) {
			$code = @file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			if ( false !== $code ) {
				return rtrim( $code ) . "\n";
			}
		}
		return '';
	}

	public static function get_loader_code() {
		return self::get_preset_code( 'apple_star' );
	}
}
